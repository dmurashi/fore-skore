<!-- src/components/event/PrizeLegend.vue -->
<template>
  <div class="prize-legend">
    <div class="legend-item">
      <span class="legend-sample both-skins"></span>
      <span>Gross + Net Skin</span>
    </div>

    <div class="legend-item">
      <span class="legend-sample gross-skin"></span>
      <span>Gross Skin</span>
    </div>

    <div class="legend-item">
      <span class="legend-sample net-skin"></span>
      <span>Net Skin</span>
    </div>

    <div class="legend-item">
      <span class="legend-sample final4-box"></span>
      <span>Final 4 Net (15–18)</span>
    </div>

    <div class="legend-item">
      <span class="legend-sample ctp">⛳</span>
      <span>Closest to the Pin</span>
    </div>

    <div class="legend-item">
      <span class="legend-sample ctp">🏅</span>
      <span>Medalist</span>
    </div>
  </div>
</template>

<style scoped>
/* Prize Legend */
.prize-legend {
  display: flex;
  flex-wrap: wrap;
  gap: 12px 18px;
  margin: 10px 0 14px;
  font-size: 12px;
  color: #374151;
}

.legend-item {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.legend-sample {
  width: 18px;
  height: 18px;
  border-radius: 0px;
  border: 1px solid #e5e7eb;
}

/* SKINS STYLING (legend samples use same classes) */
.gross-skin {
  background-image:
    repeating-linear-gradient(
      45deg,
      rgba(36, 212, 1, 0.9),
      rgba(242, 12, 12, 0.08) 2px,
      rgba(242, 12, 12, 0.03) 2px,
      rgba(242, 12, 12, 0.04) 3px
    );
}

.net-skin {
  background-image:
    repeating-linear-gradient(
      45deg,
      rgba(251, 156, 13, 0.993),
      rgba(242, 12, 12, 0.08) 2px,
      rgba(242, 12, 12, 0.03) 2px,
      rgba(242, 12, 12, 0.04) 3px
    );
}

.both-skins {
  background-color: #f9450eed; /* red */
  background-image:
    repeating-linear-gradient(
      45deg,
      rgba(255, 255, 255, 0.48),
      rgba(255, 255, 255, 0.08) 2px,
      rgba(0, 0, 0, 0.08) 3px,
      rgba(0, 0, 0, 0.08) 4px
    );
}

/* FINAL 4 outline sample */
.legend-sample.final4-box {
  border: 2px solid #2563eb;
  background: transparent;
}

/* CTP */
.legend-sample.ctp {
  font-size: 14px;
  width: auto;
  height: auto;
  border: none;
}

/* Medal */
.legend-sample.medal {
  font-size: 14px;
  width: auto;
  height: auto;
  border: none;
}
</style>

