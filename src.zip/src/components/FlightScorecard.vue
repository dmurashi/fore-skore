<script setup lang="ts">
/* ---------- Imports ---------- */
import { computed } from 'vue'

/* ---------- Types ---------- */

interface Player {
  player_id?: number
  name: string
  flight: string

  // future-ready placeholders
  gross_total?: number
  net_total?: number
}

/* ---------- Props ---------- */

const props = defineProps<{
  flight: string
  players: Player[]
}>()

/* ---------- Derived ---------- */

const sortedPlayers = computed(() => {
  // placeholder: alphabetical for now
  // later: sort by gross / net / leaderboard rules
  return [...props.players].sort((a, b) =>
    a.name.localeCompare(b.name)
  )
})
</script>

<template>
  <section class="flight-scorecard">
    <!-- Flight Header -->
    <h2 class="flight-title">
      Flight {{ flight }}
    </h2>

    <!-- Scorecard Table -->
    <table class="scorecard">
      <thead>
        <tr>
          <th class="player-col">Player</th>

          <!-- OUT / IN / TOTAL placeholders -->
          <th class="numeric">OUT</th>
          <th class="numeric">IN</th>
          <th class="numeric">TOTAL</th>
        </tr>
      </thead>

      <tbody>
        <tr
          v-for="player in sortedPlayers"
          :key="player.player_id ?? player.name"
        >
          <td class="player-col">
            {{ player.name }}
          </td>

          <!-- Placeholder cells -->
          <td class="numeric muted">—</td>
          <td class="numeric muted">—</td>
          <td class="numeric muted">—</td>
        </tr>
      </tbody>
    </table>
  </section>
</template>

<style scoped>
.flight-scorecard {
  margin-bottom: 2rem;
}

.flight-title {
  margin: 1.5rem 0 0.5rem;
  font-weight: 600;
}

.scorecard {
  width: 100%;
  border-collapse: collapse;
  font-size: 14px;
}

.scorecard th,
.scorecard td {
  border: 1px solid #e5e7eb;
  padding: 6px 8px;
}

.scorecard th {
  background: #f9fafb;
  font-weight: 600;
}

.player-col {
  text-align: left;
  white-space: nowrap;
}

.numeric {
  text-align: right;
}

.muted {
  color: #9ca3af;
}
</style>
