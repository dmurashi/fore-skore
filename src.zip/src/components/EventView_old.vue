<script setup>
import { ref, computed } from 'vue'
import courseManifest from '../assets/courses/moon_valley_course.json'
import FlightPrizeSummary from './FlightPrizeSummary.vue'
import { formatCurrency, totalPayout } from '../utils/money.js'

import { buildFlightPrizeSummary } from '../utils/prizeReducer.js'


const eventJson = computed(() => ({
  players: props.players
}))

const prizeSummaries = computed(() => {
  if (!eventJson.value) return []
  return buildFlightPrizeSummary(eventJson.value)
})

const flightPlayerCount = computed(() => {
  const flightId = props.flight
  const list = eventJson.value?.players ?? []
  return list.filter(p => p.flight === flightId).length
})

const prizeView = ref(false)

/* ---------- Props ---------- */

const props = defineProps({
  flight: { type: String, required: true },
  players: { type: Array, required: true }
})

/* ---------- Constants ---------- */

const frontNine = Array.from({ length: 9 }, (_, i) => i + 1)
const backNine  = Array.from({ length: 9 }, (_, i) => i + 10)

/* ---------- Gross / Net Toggle ---------- */

const scoreMode = ref('gross') // 'gross' | 'net'
const scoreModeLabel = computed(() =>
  scoreMode.value === 'gross' ? 'Gross' : 'Net'
)


/* ---------- Course / Tee ---------- */

const teeSetId = '1'

const teeSet = computed(() =>
  courseManifest.tee_sets?.[teeSetId] ?? { holes: {} }
)

/* ---------- PAR totals ---------- */

const frontNinePar = computed(() =>
  frontNine.reduce(
    (sum, h) => sum + (teeSet.value.holes[String(h)]?.par?.men ?? 0),
    0
  )
)

const backNinePar = computed(() =>
  backNine.reduce(
    (sum, h) => sum + (teeSet.value.holes[String(h)]?.par?.men ?? 0),
    0
  )
)

const totalPar = computed(() => frontNinePar.value + backNinePar.value)

/* ---------- Score helpers ---------- */

function getHole(player, holeNumber) {
  return player.holes?.[String(holeNumber)] ?? null
}

function getScore(player, holeNumber) {
  const hole = getHole(player, holeNumber)
  if (!hole) return null
  return scoreMode.value === 'gross' ? hole.gross : hole.net
}

function scoreClass(player, holeNumber) {
  const hole = getHole(player, holeNumber)
  if (!hole) return null

  const diff =
    scoreMode.value === 'gross'
      ? hole.gross_diff
      : hole.net_diff

  if (diff >= 2) return 'score-dbl-bogey-plus'

  const result =
    scoreMode.value === 'gross'
      ? hole.gross_result
      : hole.net_result

  if (result === 'EAGLE')  return 'score-eagle'
  if (result === 'BIRDIE') return 'score-birdie'
  if (result === 'BOGEY')  return 'score-bogey'

  return null
}

function sumHoles(player, holes) {
  let total = 0
  let hasScore = false

  for (const h of holes) {
    const score = getScore(player, h)
    if (score !== null) {
      total += score
      hasScore = true
    }
  }

  return hasScore ? total : null
}

/* ---------- Tee badge ---------- */

function teeStyle(tee) {
  if (!tee) return {}

  const colors = tee.split('/').map(t => t.trim().toLowerCase())

  const colorMap = {
    black: '#111827',
    blue:  '#2563eb',
    white: '#ffffff',
    red:   '#fc5a5a'
  }

  if (colors.length === 1) {
    return {
      backgroundColor: colorMap[colors[0]] || '#e5e7eb',
      border: colors[0] === 'white'
        ? '1px solid #9ca3af'
        : 'none'
    }
  }

  const c1 = colorMap[colors[0]] || '#e5e7eb'
  const c2 = colorMap[colors[1]] || '#e5e7eb'

  return {
    background: `linear-gradient(135deg, ${c1} 50%, ${c2} 50%)`,
    border: '1px solid #d1d5db'
  }
}


/* ---------- Derived (single source of truth) ---------- */

const viewPlayers = computed(() => {
  return [...props.players]
    .map(player => {
      const frontTotal = sumHoles(player, frontNine)
      const backTotal  = sumHoles(player, backNine)

      const total =
        scoreMode.value === 'gross'
          ? player.gross_total ?? null
          : player.net_total ?? null

      return {
        ...player,
        frontTotal,
        backTotal,
        total
      }
    })
    .sort((a, b) => {
      if (a.total === null && b.total === null) {
        return a.name.localeCompare(b.name)
      }
      if (a.total === null) return 1
      if (b.total === null) return -1
      if (a.total !== b.total) return a.total - b.total
      return a.name.localeCompare(b.name)
    })
})
// PRIZE HELPERS
function hasFinal4(player) {
  return player.round_competitions?.some(
    c => c.type === 'FINAL_4_NET'
  )
}

function hasGrossSkin(hole) {
  return hole?.competitions?.some(c => c.type === 'GROSS_SKINS')
}
function hasNetSkin(hole) {
  return hole?.competitions?.some(c => c.type === 'NET_SKINS')
}

function hasBothSkins(hole) {
  return hasGrossSkin(hole) && hasNetSkin(hole)
}
function hasCTP(hole) {
  return hole?.competitions?.some(c => c.type === 'CTP')
}
function isLowGrossWinner(player) {
  return player.gross_rank === 1
}

function holeClasses(player, holeNumber) {
  const classes = []

    // FINAL_4_NET (unchanged)
    if (
        prizeView.value &&
        hasFinal4(player) &&
        holeNumber >= 15 &&
        holeNumber <= 18
    ) {
        classes.push('final4')
        if (holeNumber === 15) classes.push('first')
        if (holeNumber === 18) classes.push('last')
    }

    const hole = player.holes?.[holeNumber]

    if (!prizeView.value || !hole) return classes

    // Both skins (highest priority)
    if (hasBothSkins(hole)) {
        classes.push('both-skins')
    }
    // Gross skin only
    else if (hasGrossSkin(hole)) {
        classes.push('gross-skin')
    }
    // Net skin only
    else if (hasNetSkin(hole)) {
        classes.push('net-skin')
    }

    return classes
}
//  dots for strokes received, + for strokes given
function strokeCount(hole) {
  if (!hole || hole.gross === null || hole.net === null) return 0
  return hole.gross - hole.net
}

function receivesStrokes(hole) {
  return strokeCount(hole) > 0
}

function givesStrokes(hole) {
  return strokeCount(hole) < 0
}

</script>

<template>


  <section class="flight-scorecard">
     <FlightPrizeSummary
        :flight-name="flight"
        :summary="prizeSummaries[flight]"
        :player-count="flightPlayerCount"
      />

    <div class="flight-header">
      <h2 class="flight-title">
        Leaderboard – Flight {{ flight }}
        (
        <span
            :style="{ color: scoreModeLabel === 'Net' ? 'red' : 'green' }"
        >
            {{ scoreModeLabel }}
        </span>
        )
    </h2>

      <div class="mode-toggle">
        <button
          class="mode-btn"
          :class="{ active: scoreMode === 'gross' }"
          @click="scoreMode = 'gross'"
        >
          Gross
        </button>
        <button
          class="mode-btn"
          :class="{ active: scoreMode === 'net' }"
          @click="scoreMode = 'net'"
        >
          Net
        </button>

        <button
            type="button"
            class="mode-btn"
            :class="{ active: prizeView }"
            @click="prizeView = !prizeView"
        >
            Prizes
        </button>
      </div>
      
    </div>

    <div v-if="prizeView" class="prize-legend">
        <!-- <div class="legend-item">
            <span class="legend-sample score-birdie"></span>
            <span>Birdie / Eagle</span>
        </div> -->
        <div class="legend-item">
            <span class="legend-sample both-skins"></span>
            <span>Gross + Net Skin</span>
        </div>

        <div class="legend-item">
            <span class="legend-sample gross-skin"></span>
            <span>Gross Skin</span>
        </div>

        <div class="legend-item">
            <span class="legend-sample net-skin"></span>
            <span>Net Skin</span>
        </div>

        <div class="legend-item">
            <span class="legend-sample final4-box"></span>
            <span>Final 4 Net (15–18)</span>
        </div>

        <div class="legend-item">
            <span class="legend-sample ctp">⛳</span>
            <span>Closest to the Pin</span>
        </div>

        <div class="legend-item">
            <span class="legend-sample ctp">🏅</span>
            <span>Medalist</span>
        </div>

        <!-- <div class="legend-item">
            <span class="legend-badge low-net">LOW NET</span>
            <span>Low Net Winner</span>
        </div> -->
    </div>


        <!-- ✅ Leaderboard: horizontally scrollable island -->
    <div class="leaderboard-scroll" aria-label="Leaderboard scroll area">
      <table class="scorecard">
        <thead>
          <tr>
            <th class="rank-col">#</th>
            <th class="player-col">Player</th>
            <th class="tee-col">Tee</th>

            <th v-for="h in frontNine" :key="h">{{ h }}</th>
            <th class="total-col">OUT</th>
            <th v-for="h in backNine" :key="h">{{ h }}</th>
            <th class="total-col">IN</th>
            <th class="total-col">TOTAL</th>
            <th class="payout-col"></th>
          </tr>

          <tr class="par-row">
            <th></th>
            <th class="player-col">PAR</th>
            <th></th>

            <th v-for="h in frontNine" :key="'pf'+h">
              {{ teeSet.holes[String(h)]?.par?.men ?? '—' }}
            </th>
            <th>{{ frontNinePar }}</th>

            <th v-for="h in backNine" :key="'pb'+h">
              {{ teeSet.holes[String(h)]?.par?.men ?? '—' }}
            </th>
            <th>{{ backNinePar }}</th>
            <th>{{ totalPar }}</th>
            <th class="payout-col">$</th>
          </tr>
        </thead>

        <tbody>
          <tr v-for="player in viewPlayers" :key="player.event_player_id">
            <td class="rank-col">
              {{ scoreMode === 'gross'
                ? player.gross_rank_label
                : player.net_rank_label
              }}
            </td>

            <td class="player-col">
              {{ player.name }}
              <span v-if="player.course_handicap !== null">
                ({{ player.course_handicap }})
              </span>

              <span
                v-if="
                  prizeView &&
                  player.round_competitions?.some(c => c.type === 'LOW_NET')
                "
                class="badge low-net"
              >
                LOW NET
              </span>

              <span
                v-if="prizeView && isLowGrossWinner(player)"
                class="badge low-gross"
                title="Low Gross"
              >
                🏅
              </span>
            </td>

            <td class="tee-col">
              <span
                class="tee-badge"
                :style="teeStyle(player.tee_name)"
                :title="player.tee_name"
              />
            </td>

            <!-- Front 9 -->
            <td
              v-for="h in frontNine"
              :key="'b'+h"
              class="hole-col"
              :class="holeClasses(player, h)"
            >
              <span
                v-if="strokeCount(player.holes?.[h]) !== 0"
                class="stroke-indicator"
              >
                <span
                  v-if="receivesStrokes(player.holes?.[h])"
                  class="stroke-dots"
                  :title="`${strokeCount(player.holes[h])} stroke(s) received`"
                >
                  {{ '●'.repeat(Math.min(strokeCount(player.holes[h]), 3)) }}
                </span>

                <span v-else class="stroke-plus" title="Giving strokes">+</span>
              </span>

              <span
                v-if="getScore(player, h) !== null"
                class="hole-score"
                :class="scoreClass(player, h)"
              >
                {{ getScore(player, h) }}
              </span>
              <span v-else class="placeholder">—</span>

              <span
                v-if="prizeView && getScore(player, h) !== null && hasCTP(player.holes?.[h])"
                class="ctp-badge"
                title="Closest to the Pin"
              >
                ⛳
              </span>
            </td>

            <td
              class="total-col"
              :class="{ 'total-under-par': player.frontTotal < frontNinePar }"
            >
              {{ player.frontTotal ?? '—' }}
            </td>

            <!-- Back 9 -->
            <td
              v-for="h in backNine"
              :key="'f'+h"
              class="hole-col"
              :class="holeClasses(player, h)"
            >
              <span
                v-if="strokeCount(player.holes?.[h]) !== 0"
                class="stroke-indicator"
              >
                <span
                  v-if="receivesStrokes(player.holes?.[h])"
                  class="stroke-dots"
                  :title="`${strokeCount(player.holes[h])} stroke(s) received`"
                >
                  {{ '●'.repeat(Math.min(strokeCount(player.holes[h]), 3)) }}
                </span>

                <span v-else class="stroke-plus" title="Giving strokes">+</span>
              </span>

              <span
                v-if="getScore(player, h) !== null"
                class="hole-score"
                :class="scoreClass(player, h)"
              >
                {{ getScore(player, h) }}
              </span>
              <span v-else class="placeholder">—</span>

              <span
                v-if="prizeView && getScore(player, h) !== null && hasCTP(player.holes?.[h])"
                class="ctp-badge"
                title="Closest to the Pin"
              >
                ⛳
              </span>
            </td>

            <td
              class="total-col"
              :class="{ 'total-under-par': player.backTotal < backNinePar }"
            >
              {{ player.backTotal ?? '—' }}
            </td>

            <td
              class="total-col"
              :class="{ 'total-under-par': player.total < totalPar }"
            >
              {{ player.total ?? '—' }}
            </td>

            <td class="payout-col">
              {{ formatCurrency(totalPayout(player)) }}
            </td>
          </tr>
        </tbody>

        <tfoot>
          <tr class="index-row">
            <th></th>
            <th>Index (M)</th>
            <th></th>
            <td v-for="h in frontNine" :key="'imf'+h">
              {{ teeSet.holes[String(h)]?.index?.men ?? '—' }}
            </td>
            <td></td>
            <td v-for="h in backNine" :key="'imb'+h">
              {{ teeSet.holes[String(h)]?.index?.men ?? '—' }}
            </td>
            <td></td>
            <td></td>
            <td></td>
          </tr>

          <tr class="index-row">
            <th></th>
            <th>Index (W)</th>
            <th></th>
            <td v-for="h in frontNine" :key="'iwf'+h">
              {{ teeSet.holes[String(h)]?.index?.women ?? '—' }}
            </td>
            <td></td>
            <td v-for="h in backNine" :key="'iwb'+h">
              {{ teeSet.holes[String(h)]?.index?.women ?? '—' }}
            </td>
            <td></td>
            <td></td>
            <td></td>
          </tr>
        </tfoot>
      </table>
    </div>

  </section>
</template>


<style scoped>

.flight-scorecard {
  margin-bottom: 2.5rem;
}

.flight-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 10px;
}

.flight-title {
  margin: 0;
  font-size: 20px;
  font-weight: 700;
  color: #111827;
}


/* Toggle */

.mode-toggle {
  display: inline-flex;
  gap: 6px;
  margin-bottom: 10px;
}

.mode-btn {
  padding: 6px 14px;
  border: 1px solid #e5e7eb;
  background: #f9fafb;
  border-radius: 10px;
  font-weight: 600;
  font-size: 13px;
  color: #6b7280;
  cursor: pointer;
  transition:
    border-color 120ms ease,
    color 120ms ease,
    background-color 120ms ease;
}

.mode-btn:hover {
  background: #f3f4f6;
}

.mode-btn.active {
  background: #ffffff;
  color: #111827;
  border-color: #2563eb;
}

/* player row Table */
.player-badge {
  display: inline-block;
  margin-left: 8px;
  padding: 2px 8px;
  font-size: 11px;
  font-weight: 700;
  border-radius: 999px;
  line-height: 1.3;
  vertical-align: middle;
  white-space: nowrap;
}


/* isolates the wide table so it doesn't stretch the page */
.leaderboard-scroll {
  width: 100%;
  max-width: 100%;
  overflow-x: auto;
  overflow-y: hidden;
  -webkit-overflow-scrolling: touch;
}
:deep(.leaderboard-scroll) {
  width: 100%;
  max-width: 100%;
  overflow-x: auto;
  overflow-y: hidden;
  -webkit-overflow-scrolling: touch;
}

/* 🔑 override "fit-to-container" table styles */
:deep(.leaderboard-scroll .scorecard) {
  width: max-content !important;
  min-width: 1100px !important;   /* adjust 1100–1400 to taste */
  table-layout: auto !important;
}

/* 🔑 prevents cells from wrapping (wrapping allows shrinking) */
:deep(.leaderboard-scroll .scorecard th),
:deep(.leaderboard-scroll .scorecard td) {
  white-space: nowrap !important;
}

.scorecard th,
.scorecard td {
  white-space: nowrap;    /* prevents squishing/wrapping */
}

.flight-scorecard {
  min-width: 0;           /* 🔑 if any parent uses flex */
}
/* make sure the table can be wider than the wrapper (so it scrolls) */
.scorecard {
  min-width: 1100px;      /* 🔑 force overflow on phones */
  width: max-content;     /* let it be wide */
}
/* ------- PRIZES --------- */

/* SKINS STYLING */
.gross-skin {
  /*background-color: #c1ef8c;  red-100 base */
  background-image:
    repeating-linear-gradient(
      45deg,
      rgba(36, 212, 1, 0.9),
      rgba(242, 12, 12, 0.08) 2px,
      rgba(242, 12, 12, 0.03) 2px,
      rgba(242, 12, 12, 0.04) 3px
    );
}

/* Net skin only — orange grain */
.net-skin {
  /* background-color: #b0dafd;  */
  background-image:
    repeating-linear-gradient(
      45deg,
      rgba(251, 156, 13, 0.993),
      rgba(242, 12, 12, 0.08) 2px,
      rgba(242, 12, 12, 0.03) 2px,
      rgba(242, 12, 12, 0.04) 3px
    );
}

/* Both gross + net skins (deeper red grain) */
.both-skins {
  background-color: #f9450eed; /* red */
  background-image:
    repeating-linear-gradient(
      45deg,
      rgba(255, 255, 255, 0.48),
      rgba(255, 255, 255, 0.08) 2px,
      rgba(0, 0, 0, 0.08) 3px,
      rgba(0, 0, 0, 0.08) 4px
    );
}

/* Ensure gross skin shading wins over row hover */
.scorecard tbody tr:hover td.gross-skin {
  background-color: #93dd3e;
  background-image:
    repeating-linear-gradient(
      45deg,
      rgba(220, 38, 38, 0.08),
      rgba(220, 38, 38, 0.08) 2px,
      rgba(220, 38, 38, 0.04) 2px,
      rgba(220, 38, 38, 0.04) 4px
    );
}

.scorecard tbody tr:hover td.net-skin {
  background-color: #f8ba73;

  background-image:
    repeating-linear-gradient(
      45deg,
      rgba(234, 88, 12, 0.12),
      rgba(234, 88, 12, 0.12) 2px,
      rgba(234, 88, 12, 0.06) 2px,
      rgba(234, 88, 12, 0.06) 4px
    );
}

.scorecard tbody tr:hover td.both-skins {
  background-color: #fd4f1a;
  background-image:
    repeating-linear-gradient(
      45deg,
      rgba(255, 255, 255, 0.08),
      rgba(255, 255, 255, 0.08) 2px,
      rgba(0, 0, 0, 0.08) 2px,
      rgba(0, 0, 0, 0.08) 4px
    );
}

/* White score number on both-skins */
.both-skins .hole-score {
  color: #ffffff;
  font-weight: 700;
}

/* FINAL 4 NET grouping — collapse-safe */
.final4 {
  box-shadow:
    inset 0 2px 0 #2563eb,
    inset 0 -2px 0 #2563eb;
}


.final4.first {
  box-shadow:
    inset 2px 0 0 #2563eb,
    inset 0 2px 0 #2563eb,
    inset 0 -2px 0 #2563eb;
}

.final4.last {
  box-shadow:
    inset -2px 0 0 #2563eb,
    inset 0 2px 0 #2563eb,
    inset 0 -2px 0 #2563eb;
}

/* CTP badge — lower right corner */
.ctp-badge {
  position: absolute;
  bottom: 1px;
  right: 1px;

  font-size: 18px;
  line-height: 1;
  pointer-events: none;
}

/* Tee column */
.tee-col {
  width: 28px;
  text-align: center;
  background-color: #F9FAFB;
}

/* Tee badge (VISIBLE + WORKING) */
.tee-badge {
  display: inline-block;
  width: 14px;
  height: 14px;
  border-radius: 2px;
  box-sizing: border-box;
}

/* Prize Legend */
.prize-legend {
  display: flex;
  flex-wrap: wrap;
  gap: 12px 18px;
  margin: 10px 0 14px;
  font-size: 12px;
  color: #374151;
}

.legend-item {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.legend-sample {
  width: 18px;
  height: 18px;
  border-radius: 0px;
  border: 1px solid #e5e7eb;
}

/* Reuse existing styles */
.legend-sample.gross-skin { @apply gross-skin; }
.legend-sample.net-skin   { @apply net-skin; }
.legend-sample.both-skins { @apply both-skins; }

/* FINAL 4 outline sample */
.legend-sample.final4-box {
  border: 2px solid #2563eb;
  background: transparent;
}

/* CTP */
.legend-sample.ctp {
  font-size: 14px;
  width: auto;
  height: auto;
  border: none;
}

/* LOW NET badge */

/* Base badge (shared) */
.badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;

  margin-left: 8px;
  padding: 2px 8px;

  font-size: 11px;
  font-weight: 700;
  border-radius: 999px;
  line-height: 1.3;
  white-space: nowrap;
}

/* LOW NET badge */
.badge.low-net {
  background: #eb253fd9; /* your existing red */
  color: #ffffff;
  margin-left: 10px;
}
.legend-badge.low-net {
  background: #ef4444;
  color: white;
  font-size: 11px;
  padding: 2px 8px;
  border-radius: 999px;
  font-weight: 700;
}
/* Make the medal icon slightly larger */
.badge.low-gross {
  font-size: 18px; /* bumps 🏅 without inflating the pill too much */
}

/* Scorecard styling */ 

/* dots for strokes */

.stroke-indicator {
  position: absolute;
  top: .3px;
  left: 52%;
  transform: translateX(-50%);
  pointer-events: none;
  line-height: 0;
  height: 0;
}

/* Stroke dots (receiving strokes) */
.stroke-dots {
  font-size: 4px;        /* smaller than before */
  line-height: 1;
  color: #870909;
  opacity: 0.5;          /* 50% transparency */
  letter-spacing: 1px;
  display: inline-block;
}

/* Plus indicator (giving strokes) */
.stroke-plus {
  font-size: 7px;        /* proportional to dots */
  font-weight: 600;
  line-height: 1;
  color: #023ec0;
  opacity: 0.5;          /* match dots */
  display: inline-block;
}


.scorecard {
  width: 100%;
  border-collapse: collapse;
  font-size: 14px;
}

.scorecard th,
.scorecard td {
  border: 1px solid #e5e7eb;
  padding: 4px 6px;
  text-align: center;
}

.scorecard th {
  background: #f9fafb;
  font-weight: 600;
}

.scorecard th.player-col,
.scorecard td.player-col {
  text-align: left;

  white-space: nowrap;
}

.scorecard tbody tr:hover td {
  background: #f3f4f6;
}

.scorecard tbody tr:hover td.player-col {
  border-left: 1.5px solid #2563eb;
}

.hole-col {
  width: 28px;
}
.hole-col {
  position: relative;
}

.total-col {
  width: 42px;
  font-weight: 600;
}

.placeholder {
  color: #9ca3af;
}

/* PAR row */

.par-row th {
  background: #f3f4f6;
  color: #6b7280;
}

.par-row th,
.par-row td {
  border-bottom: 2px solid #e5e7eb;
}

.index-row th:nth-child(2) {
  text-align: left !important;
  padding-left: 12px;
}

/* Index rows */

.index-row th,
.index-row td {
  background: #fafafa;
  color: #6b7280;
  font-size: 12px;
}

tfoot tr:first-child th,
tfoot tr:first-child td {
  border-top: 2px solid #e5e7eb; 
}

.total-under-par {
  color: #dc2626; /* red-600 */
}

/* ---------- Hole score styling ---------- */

.player-name {
  margin-right: 4px;
}

.player-hcap {
  color: #6b7280;       /* gray-500 */
  font-weight: 500;
  font-size: 12px;
}


.rank-col {
  width: 32px;
  min-width: 32px;
  max-width: 32px;
  text-align: center;
  font-weight: 600;
  color: #374151; /* gray-700 */
}

.rank-badge {
  display: inline-block;
  min-width: 28px;
}


.rank-col {
  width: 28px;
  text-align: center;
  font-weight: 600;
}


.hole-score {
  display: inline-flex;
  align-items: center;
  justify-content: center;

  width: 24px;
  height: 24px;

  font-weight: 400;
  line-height: 1;

  box-sizing: border-box; /* CRITICAL */
}


/* Birdie → single circle */
.score-birdie {
  border: 1.5px solid #22c55e; /* green-500 */
  border-radius: 50%;
}

/* Eagle → double circle */
.score-eagle {
  position: relative;
  border: 1.5px solid #16a34a; /* darker green */
  border-radius: 50%;
}

.score-eagle::after {
  content: '';
  position: absolute;
  inset: 1.3px;
  border: 1.5px solid #16a34a;
  border-radius: 50%;
}

/* Bogey → square */
.score-bogey {
  border: 1px solid #9ca3af; /* gray-400 */
  border-radius: 3px;
}

/* Double bogey or worse → double square */
.score-dbl-bogey-plus {
  position: relative;
  border: 1px solid #9ca3af; /* red-600 */
  border-radius: 3px;
}

.score-dbl-bogey-plus::after {
  content: '';
  position: absolute;
  inset: 1.5px;               /* controls spacing between squares */
  border: 1px solid #9ca3af;
  border-radius: 2px;
}


</style>
