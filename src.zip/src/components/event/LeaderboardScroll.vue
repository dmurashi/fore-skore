<!-- LeaderboardScroll.vue -->
<template>
  <div class="leaderboard-scroll" aria-label="Leaderboard scroll area">
    <slot />
  </div>
</template>

<style scoped>
/*
  This element must be the ONLY horizontal overflow boundary.
  It should not allow child intrinsic width (e.g. max-content tables)
  to affect the page / other sections (summary cards).
*/
.leaderboard-scroll {
  width: 100%;
  max-width: 100%;
  min-width: 0;

  overflow-x: auto;
  overflow-y: hidden;
  -webkit-overflow-scrolling: touch;

  contain: layout paint;
}

/* Keep the table from wrapping; allow it to be wider than the container */
:deep(.scorecard) {
  min-width: 1100px;
  border-collapse: collapse;
}

/* Prevent wrapping inside cells (this is fine to enforce here) */
:deep(.scorecard th),
:deep(.scorecard td) {
  white-space: nowrap;
}
</style>
